import numpy as np
from scipy import stats
data=[12,15,12,18,20,22,22,22,25,30]
mean=np.mean(data)
median=np.median(data)
mode=stats.mode(data)[0]
variance=np.var(data)
std_deviation=np.std(data)
print(f"mean : {mean}")
print(f"median : {median}")
print(f"mode : {mode}")
print(f"variance : {variance}")
print(f"standard DEVIATION: {std_deviation}")
